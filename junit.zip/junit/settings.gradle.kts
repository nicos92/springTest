rootProject.name = "junit"
